# Technical Report Outline — Robotic Car Painting Cell (PyBullet)
Fill every number from `report/results.json` / console reachability table. Do not invent values.

1. **Introduction** – robotic spray painting in automotive lines; purpose of simulation.
2. **Objective** – required items (car, robot, tool, cell, trajectories, collision, multi-surface).
3. **Software Used** – Python, PyBullet, NumPy; why PyBullet (open, scriptable, IK + collision queries).
4. **System Architecture** – module diagram (config → models → planner → executor → HUD); control loop 240 Hz.
5. **Car Model** – primitives, 4.8×1.9×1.6 m, separate compound collision body.
6. **Industrial Robot** – 6-DOF kinematics, link lengths, joint limits/velocities, rail carriage (7th axis) and why.
7. **Painting End-Effector** – gun, nozzle, TCP, spray cone, footprint geometry.
8. **Cell Layout** – floor, rail loop, stations, fence + virtual safety walls, camera views.
9. **Trajectory Planning** – zig-zag passes, standoff, tilt, timing, Hermite smoothing, corner dwell. Table: passes, nodes, path length.
10. **Inverse Kinematics** – DLS IK, seeding, FK verification, singularity margin, staged joint routes.
11. **Collision Checking** – queries used, thresholds (WARN 0.10 m, HIT 0.02 m), planning vs runtime use, collision-test demo (X key).
12. **Reachability** – per-surface table (nodes, reachable, jumps, min clearance, success).
13. **Painting Process** – spray conditions, coverage grid, progress metric.
14. **Results** – execution time, coverage %, runtime min clearance, warnings, collisions (from results.json); screenshots.
15. **Limitations** – see README.
16. **Future Improvements** – self-collision, paint-thickness model, OMPL/RRT planning, dynamic rail, tool-orientation optimisation, multi-robot.
